#ifndef OPENINGWINDOW_H
#define OPENINGWINDOW_H


class OpeningWindow
{
public:
    OpeningWindow();
};

#endif // OPENINGWINDOW_H
